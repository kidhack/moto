import { useState, useEffect } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useWalletInfo, useEnsureWallet, useResetOnboarding, useSignOutAndReset } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { LogOut, MoreVertical, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import WalletOverview from '../components/WalletOverview';
import SendTransaction from '../components/SendTransaction';
import ReceiveBitcoin from '../components/ReceiveBitcoin';
import TransactionHistory from '../components/TransactionHistory';

export default function WalletDashboard() {
  const { clear, identity } = useInternetIdentity();
  const { data: walletInfo, isLoading } = useWalletInfo();
  const ensureWallet = useEnsureWallet();
  const resetOnboarding = useResetOnboarding();
  const signOutAndReset = useSignOutAndReset();
  const [activeTab, setActiveTab] = useState('overview');
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [showSignOutDialog, setShowSignOutDialog] = useState(false);

  // Automatically ensure wallet exists when component mounts
  useEffect(() => {
    if (!isLoading && !walletInfo && !ensureWallet.isPending) {
      ensureWallet.mutate();
    }
  }, [isLoading, walletInfo, ensureWallet]);

  const handleResetOnboarding = async () => {
    try {
      await resetOnboarding.mutateAsync();
      toast.success('Onboarding reset successfully');
      // Log out the user so they can experience the onboarding flow again
      setTimeout(() => {
        clear();
      }, 1000);
    } catch (error) {
      toast.error('Failed to reset onboarding');
    }
  };

  const handleSignOutAndReset = async () => {
    try {
      await signOutAndReset.mutateAsync();
      toast.success('Signed out successfully');
      // Clear Internet Identity session and return to splash
      setTimeout(() => {
        clear();
        // Force reload to reset all state and show splash screen
        window.location.reload();
      }, 500);
    } catch (error) {
      console.error('Sign out error:', error);
      toast.error('Failed to sign out');
    }
  };

  if (isLoading || ensureWallet.isPending || (!walletInfo && !ensureWallet.isError)) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="flex flex-col items-center gap-4">
          <img src="/assets/markettown-logo-w.svg" alt="market.town" className="h-16" />
          <p className="text-sm text-white/60">
            {ensureWallet.isPending ? 'Setting up your wallet...' : 'Loading wallet...'}
          </p>
        </div>
      </div>
    );
  }

  if (ensureWallet.isError) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/assets/markettown-logo-w.svg" alt="market.town" className="h-6" />
            </div>
            <Button variant="ghost" size="sm" onClick={clear}>
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out
            </Button>
          </div>
        </header>

        <main className="flex flex-1 items-center justify-center p-4">
          <div className="text-center">
            <p className="text-destructive mb-4">Failed to initialize wallet</p>
            <Button onClick={() => ensureWallet.mutate()} variant="outline">
              Retry
            </Button>
          </div>
        </main>
      </div>
    );
  }

  if (!walletInfo) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="flex flex-col items-center gap-4">
          <img src="/assets/markettown-logo-w.svg" alt="market.town" className="h-16" />
          <p className="text-sm text-white/60">Loading wallet...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/assets/markettown-logo-w.svg" alt="market.town" className="h-6" />
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden text-right sm:block">
              <p className="text-xs text-muted-foreground">Principal</p>
              <p className="text-sm font-mono">
                {identity?.getPrincipal().toString().slice(0, 8)}...
                {identity?.getPrincipal().toString().slice(-6)}
              </p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setShowResetDialog(true)}>
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Reset Onboarding
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setShowSignOutDialog(true)}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out & Reset
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <main className="flex-1 py-8">
        <div className="container max-w-6xl">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="send">Send</TabsTrigger>
              <TabsTrigger value="receive">Receive</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <WalletOverview wallet={walletInfo} />
            </TabsContent>

            <TabsContent value="send">
              <SendTransaction wallet={walletInfo} />
            </TabsContent>

            <TabsContent value="receive">
              <ReceiveBitcoin address={walletInfo.bitcoinAddress} />
            </TabsContent>

            <TabsContent value="history">
              <TransactionHistory transactions={walletInfo.transactions} />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <footer className="border-t border-border/40 py-6">
        <div className="container text-center text-sm text-muted-foreground">
          © 2025. Built with <span className="text-bitcoin">♥</span> using{' '}
          <a href="https://caffeine.ai" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">
            caffeine.ai
          </a>
        </div>
      </footer>

      <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset Onboarding?</AlertDialogTitle>
            <AlertDialogDescription>
              This will reset your onboarding state and you'll see the first-time user experience again on your next login. You will be signed out after the reset.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleResetOnboarding} disabled={resetOnboarding.isPending}>
              {resetOnboarding.isPending ? 'Resetting...' : 'Reset Onboarding'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showSignOutDialog} onOpenChange={setShowSignOutDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sign Out & Reset?</AlertDialogTitle>
            <AlertDialogDescription>
              This will sign you out and clear all session data. You'll need to authenticate again to access your wallet. This action will return you to the splash screen as if you were a new user.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSignOutAndReset} disabled={signOutAndReset.isPending}>
              {signOutAndReset.isPending ? 'Signing Out...' : 'Sign Out & Reset'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
