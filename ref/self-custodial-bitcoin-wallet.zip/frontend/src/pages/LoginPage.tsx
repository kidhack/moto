import { useState, useEffect } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';

interface LoginPageProps {
  showSplashAnimation?: boolean;
}

export default function LoginPage({ showSplashAnimation = false }: LoginPageProps) {
  const { login, isLoggingIn } = useInternetIdentity();
  const [animationStarted, setAnimationStarted] = useState(false);

  useEffect(() => {
    if (showSplashAnimation) {
      // Start animation after 3 seconds (50% slower)
      const timer = setTimeout(() => {
        setAnimationStarted(true);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showSplashAnimation]);

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-black p-6 text-white">
      {/* Logo container - animates from center to top */}
      <div 
        className="absolute left-0 right-0 flex justify-center transition-all duration-[2250ms]"
        style={{
          top: showSplashAnimation && !animationStarted ? '50%' : '3rem',
          transform: showSplashAnimation && !animationStarted ? 'translateY(-50%)' : 'translateY(0)',
          transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
          zIndex: 20
        }}
      >
        <div className="flex flex-col items-center gap-6">
          {/* Market Town Mark - stays visible throughout */}
          <img 
            src="/assets/mt mark.svg" 
            alt="Market Town" 
            className="h-16"
          />
          
          {/* Market Town Type - fades out during animation */}
          {showSplashAnimation && (
            <img 
              src="/assets/mt type.svg" 
              alt="Market Town Type" 
              className="h-8 transition-opacity duration-[1200ms]"
              style={{
                opacity: animationStarted ? 0 : 1,
                transitionTimingFunction: 'ease-out'
              }}
            />
          )}
        </div>
      </div>

      {/* Login content - fades in during animation */}
      <div 
        className="relative flex flex-1 flex-col transition-opacity duration-[1200ms]"
        style={{
          opacity: showSplashAnimation && !animationStarted ? 0 : 1,
          transitionDelay: showSplashAnimation ? '900ms' : '0ms',
          transitionTimingFunction: 'ease-in',
          pointerEvents: showSplashAnimation && !animationStarted ? 'none' : 'auto'
        }}
      >
        {/* Spacer for logo at top */}
        <div className="flex justify-center pt-12">
          <div className="h-16" />
        </div>
        
        <div className="flex flex-1 flex-col items-center justify-center">
          <div className="w-full max-w-md space-y-8 text-center">
            <div className="space-y-6">
              <p className="text-lg leading-relaxed">
                Welcome to Market Town,<br />
                your new Bitcoin wallet.
              </p>
              
              <p className="text-lg leading-relaxed">
                Like a cash wallet,<br />
                use this is for everyday transactions,<br />
                not your life savings.
              </p>
              
              <p className="text-lg leading-relaxed">
                Remember: your phone is your wallet.
              </p>
              
              <p className="text-lg leading-relaxed">
                Keep it safe.
              </p>
            </div>
          </div>
        </div>

        <div className="w-full max-w-md mx-auto pb-8">
          <Button
            onClick={login}
            disabled={isLoggingIn}
            variant="outline"
            size="lg"
            className="h-14 w-full rounded-none border-2 border-white bg-transparent text-base font-normal text-white hover:bg-white hover:text-black"
          >
            {isLoggingIn ? (
              <>
                <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                Connecting...
              </>
            ) : (
              'Sign In'
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
